"use client";
import React, { useMemo } from "react";
import { useCapabilities } from "@/features/capabilities/Provider";

export function L1Grid() {
  const { roots, byId, domain, query } = useCapabilities();
  const items = useMemo(()=> {
    const q = query.trim().toLowerCase();
    return roots
      .map(id => byId[id])
      .filter(n => domain==="All Domains" ? true : n.domain===domain)
      .filter(n => q ? n.name.toLowerCase().includes(q) : true)
      .map(n => n.id);
  }, [roots, byId, domain, query]);

  return (
    <div className="grid-auto">
      {items.map(id => <Tile key={id} id={id} />)}
    </div>
  );
}

function Tile({ id }: { id:string }) {
  const L1Tile = require("./L1Tile").L1Tile;
  return <L1Tile id={id} />;
}
