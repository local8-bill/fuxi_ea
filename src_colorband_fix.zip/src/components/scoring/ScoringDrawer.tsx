"use client";
import React, { useEffect } from "react";
import { useCapabilities } from "@/features/capabilities/Provider";
import type { Scores } from "@/lib/scoring";
import { ScoreSlider } from "./ScoreSlider";

export function ScoringDrawer({ onClose }:{ onClose:()=>void }) {
  const {
    openId, setOpenId, selectedId, setSelectedId,
    byId, children, effectiveScores, updateScore, compositeFor, weights
  } = useCapabilities();

  const l1 = openId ? byId[openId] : null;
  if (!l1) return null;
  const l2Ids = children[l1.id] ?? [];

  useEffect(()=> {
    if (!selectedId && l2Ids.length) setSelectedId(l2Ids[0]);
    if (selectedId && !byId[selectedId]) setSelectedId(null);
  }, [l2Ids.join(","), selectedId]); // eslint-disable-line react-hooks/exhaustive-deps

  const active = selectedId ? byId[selectedId] : null;
  const eff = active ? effectiveScores(active.id) : null;
  const comp100 = active ? Math.round(compositeFor(active.id, weights)*100) : null;

  return (
    <div className="sheet">
      <div className="sheet-header flex items-center justify-between">
        <div>
          <div className="text-base font-semibold">{l1.name}</div>
          {l1.domain && <div className="text-xs text-slate-600">{l1.domain}</div>}
        </div>
        <button className="btn" onClick={()=>{ setOpenId(null); setSelectedId(null); onClose(); }}>Close</button>
      </div>

      <div className="sheet-body grid grid-cols-1 md:grid-cols-[320px_1fr] gap-3">
        <div className="border rounded-lg">
          <div className="px-3 py-2 border-b text-xs text-slate-600">Sub-capabilities</div>
          <div className="max-h-[70vh] overflow-auto">
            {l2Ids.map(id => {
              const node = byId[id];
              const isActive = id === selectedId;
              const l3s = children[id] ?? [];
              return (
                <button
                  key={id}
                  className={`w-full text-left px-3 py-2 border-b hover:bg-slate-50 ${isActive ? "bg-slate-50" : ""}`}
                  onClick={()=> setSelectedId(id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="text-sm">{node.name}</div>
                    <span className="badge">{Math.round(compositeFor(id, weights)*100)}/100</span>
                  </div>
                  {l3s.length>0 && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {l3s.slice(0,6).map(l3 => (
                        <span key={l3} className="badge" onClick={(e)=>{ e.stopPropagation(); setSelectedId(l3); }}>
                          {byId[l3].name}
                        </span>
                      ))}
                      {l3s.length>6 && <span className="badge">+{l3s.length-6} more</span>}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="border rounded-lg p-4">
          {!active ? (
            <div className="text-sm text-slate-600">Select a capability to score.</div>
          ) : (
            <>
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-base font-semibold">{active.name}</div>
                  {comp100 !== null && <div className="text-xs text-slate-600">Composite: <span className="font-medium">{comp100}/100</span></div>}
                </div>
              </div>

              <div className="mt-4 space-y-4">
                {([
                  ["Opportunity","opportunity"],
                  ["Maturity","maturity"],
                  ["Tech Fit","techFit"],
                  ["Strategic Alignment","strategicAlignment"],
                  ["People Readiness","peopleReadiness"],
                ] as const).map(([label, key]) => (
                  <ScoreSlider
                    key={key}
                    label={label}
                    value={eff ? eff[key] : 3}
                    onChange={(v) => updateScore(active.id, key as keyof Scores, v)}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
