"use client";
import React from "react";

export function ScoreSlider({
  label, value, onChange
}: { label:string; value:number; onChange:(v:number)=>void }) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <div className="text-sm">{label}</div>
        <div className="badge">{value}</div>
      </div>
      <input type="range" min={1} max={5} step={1}
        value={value}
        onChange={(e)=> onChange(Number(e.target.value))}
        className="w-full mt-1"
      />
      <div className="flex justify-between text-[10px] text-slate-500 mt-1">
        <span>1 • Emerging</span><span>3 • Established</span><span>5 • Leading</span>
      </div>
    </div>
  );
}
