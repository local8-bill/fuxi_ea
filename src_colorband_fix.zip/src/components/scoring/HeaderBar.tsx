"use client";
import React, { useState } from "react";
import type { Weights } from "@/lib/scoring";

export function HeaderBar({
  query, setQuery, domain, setDomain, domains,
  view, setView, weights, setWeights
}: {
  query:string; setQuery:(v:string)=>void;
  domain:string; setDomain:(v:string)=>void;
  domains:string[];
  view:"grid"|"heat"; setView:(v:"grid"|"heat")=>void;
  weights:Weights; setWeights:(w:Weights)=>void;
}) {
  const [showWeights, setShowWeights] = useState(false);

  return (
    <div className="card space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <input className="input w-[260px]" placeholder="Search capabilities…" value={query} onChange={(e)=>setQuery(e.target.value)} />
        <select className="select" value={domain} onChange={(e)=>setDomain(e.target.value)}>
          {domains.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
        <div className="ml-auto flex gap-1">
          <button className={`btn ${view==="grid"?"btn-primary":""}`} onClick={()=>setView("grid")}>Grid</button>
          <button className={`btn ${view==="heat"?"btn-primary":""}`} onClick={()=>setView("heat")}>Heatmap</button>
          <button className="btn" onClick={()=>setShowWeights(!showWeights)}>Weights</button>
        </div>
      </div>

      {showWeights && (
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
          {[
            ["Opportunity","opportunity"],
            ["Maturity","maturity"],
            ["Tech Fit","techFit"],
            ["Strategic","strategicAlignment"],
            ["People","peopleReadiness"],
          ].map(([label, key]: any) => (
            <div key={key}>
              <div className="text-xs text-slate-600 mb-1">{label}</div>
              <input type="range" min={0} max={100} step={5}
                value={Math.round((weights as any)[key]*100)}
                onChange={(e)=>{
                  const pct = Number(e.target.value)/100;
                  setWeights({ ...weights, [key]: pct } as Weights);
                }}
                className="w-full"
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
