// src/lib/colorBand.ts
// Map a 0..1 score to a CSS class band. We keep class names abstract so themes can map them.
export type Band = "band-low" | "band-med" | "band-high" | "band-extreme";

/**
 * colorBand — returns a CSS class token representing the score band.
 * Accepts either 0..1 or 0..100; values >1 are treated as percentages.
 */
export function colorBand(score: number): Band {
  const pct = score > 1 ? score : score * 100;
  if (pct >= 85) return "band-extreme";
  if (pct >= 70) return "band-high";
  if (pct >= 50) return "band-med";
  return "band-low";
}
